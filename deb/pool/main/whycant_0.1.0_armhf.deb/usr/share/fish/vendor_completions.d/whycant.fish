# fish completion for whycant
complete -c whycant -f
complete -c whycant -n '__fish_is_nth_token 1' -a 'read write append exec list traverse create delete completion'
complete -c whycant -n '__fish_is_nth_token 2' -F
complete -c whycant -s u -l user -x -a '(__fish_complete_users)' -d 'Check on behalf of this user'
complete -c whycant -s g -l group -x -a '(__fish_complete_groups)' -d 'Also assume this group'
complete -c whycant -s p -l pid -x -a '(__fish_complete_pids)' -d "Use a running process's credentials"
complete -c whycant -s a -l all -d 'Report every problem'
complete -c whycant -s v -l verbose -d 'Show passing checks'
complete -c whycant -l json -d 'Print JSON'
complete -c whycant -l verify -d 'Confirm with a real kernel access check'
complete -c whycant -l color -x -a 'auto always never' -d 'When to use color'
complete -c whycant -s q -l quiet -d 'Print only the verdict'
complete -c whycant -s h -l help -d 'Show help'
complete -c whycant -l version -d 'Show version'
